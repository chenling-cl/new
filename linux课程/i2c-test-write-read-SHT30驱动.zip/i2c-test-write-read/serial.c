
#include <termios.h>
#include <linux/serial.h>
#include <asm/ioctls.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>

#include <stdio.h>              /* perror, printf, puts, fprintf, fputs */
#include <unistd.h>             /* read, write, close */
#include <fcntl.h>              /* open */
#include <sys/signal.h>
#include <sys/types.h>
#include <string.h>             /* bzero, memcpy */
#include <limits.h>             /* CHAR_MAX */

#include "serial.h"

#define TIMEOUT_SEC(buflen,baud) (buflen*20/baud+2)
#define TIMEOUT_USEC 0

#define BUFFER_LEN	1024    /* sendfile() */

#define DEFAULT_DEVICE	"/dev/ttyS"

static void     SetBaudrate (SerialAttr* sattr, int baudrate);

static int    GetBaudrate (SerialAttr* sattr);

static void     SetDataBit (SerialAttr* sattr, int databit);

static int    BAUDRATE (int baudrate);

static int    _BAUDRATE (int baudrate);

int    ComPortSetPortAttr (SerialAttr* sattr, int baudrate, int databit,
                             const char *stopbit, char parity);

static void     SetStopBit (SerialAttr* sattr, const char *stopbit);

static void     SetParityCheck (SerialAttr* sattr, char parity);


/* Open serial port ComPort at baudrate baud rate. */
int OpenComPort (SerialAttr* sattr, char* device, int ComPort, int baudrate, int databit,
                   const char *stopbit, char parity)
{
	char pComPort[32];
	char tmpchar[2];
	int retval;
	//struct serial_struct Serial;
	tmpchar[0]=ComPort+'0';
	tmpchar[1]=0;
	bzero(pComPort, sizeof(pComPort));
	if(device==NULL){
		sprintf(pComPort,"%s%s",(char*)DEFAULT_DEVICE,tmpchar);
	}else{
		sprintf(pComPort,"%s%s",device,tmpchar);
	}
	//printf("Open port: %s\n",pComPort);
	sattr->fd = open (pComPort, O_RDWR | O_NOCTTY | O_NONBLOCK);
	if (-1 == sattr->fd) {
		fprintf (stderr, "cannot open port %s\n", pComPort);
		return (-1);
	}
	tcgetattr (sattr->fd, &sattr->termios_old);       /* save old termios value */
	/* 0 on success, -1 on failure */
	retval = ComPortSetPortAttr (sattr, baudrate, databit, stopbit, parity);
	if (-1 == retval) {
		fprintf (stderr, "\nport %s cannot set baudrate at %d\n", pComPort,
			baudrate);
	}
	return (retval);
}

/* close serial port by use of file descriptor fd */
void CloseComPort (SerialAttr* sattr)
{
	if(sattr->fd<0){
		return;
	}
    /* flush output data before close and restore old attribute */
   tcsetattr (sattr->fd, TCSADRAIN, &sattr->termios_old);
    close (sattr->fd);
	sattr->fd=-1;
}

int ReadComPort (SerialAttr* sattr, void *data, int datalength)
{
    int retval = 0;

	if(sattr->fd<0)  return -1;
    FD_ZERO (&sattr->fs_read);
    FD_SET (sattr->fd, &sattr->fs_read);
   sattr->tv_timeout.tv_sec = TIMEOUT_SEC (datalength, GetBaudrate (sattr));
    sattr->tv_timeout.tv_usec = TIMEOUT_USEC;
    retval = select (sattr->fd + 1, &sattr->fs_read, NULL, NULL, &sattr->tv_timeout);
    if (retval) {
        return (read (sattr->fd, data, datalength));
    }
    else
        return (-1);
}

int WriteComPort (SerialAttr* sattr, unsigned char * data, int datalength)
{
    int           retval, len = 0, total_len = 0;

	if(sattr->fd<0)  return -1;

    FD_ZERO (&sattr->fs_write);
    FD_SET (sattr->fd, &sattr->fs_write);
    sattr->tv_timeout.tv_sec = TIMEOUT_SEC (datalength, GetBaudrate (sattr));
    sattr->tv_timeout.tv_usec = TIMEOUT_USEC;
    for (total_len = 0, len = 0; total_len < datalength;) {
        retval = select (sattr->fd + 1, NULL, &sattr->fs_write, NULL, &sattr->tv_timeout);
        if (retval) {
            len = write (sattr->fd, &data[total_len], datalength - total_len);
            if (len > 0) {
                total_len += len;
            }
        }
        else {
            tcflush (sattr->fd, TCOFLUSH);     /* flush all output data */
            break;
        }
    }
    return (total_len);
}


/* get serial port baudrate */
static int GetBaudrate (SerialAttr* sattr)
{
    return (_BAUDRATE (cfgetospeed (&sattr->termios_new)));
}

/* set serial port baudrate by use of file descriptor fd */
static void SetBaudrate (SerialAttr* sattr, int baudrate)
{
    sattr->termios_new.c_cflag = BAUDRATE (baudrate);  /* set baudrate */
}

static void SetDataBit (SerialAttr* sattr, int databit)
{
    sattr->termios_new.c_cflag &= ~CSIZE;
    switch (databit) {
    case 8:
       sattr->termios_new.c_cflag |= CS8;
        break;
    case 7:
        sattr->termios_new.c_cflag |= CS7;
        break;
    case 6:
        sattr->termios_new.c_cflag |= CS6;
        break;
    case 5:
        sattr->termios_new.c_cflag |= CS5;
        break;
    default:
        sattr->termios_new.c_cflag |= CS8;
        break;
    }
}

static void SetStopBit (SerialAttr* sattr, const char *stopbit)
{
    if (0 == strcmp (stopbit, "1")) {
        sattr->termios_new.c_cflag &= ~CSTOPB; /* 1 stop bit */
    }
    else if (0 == strcmp (stopbit, "1.5")) {
        sattr->termios_new.c_cflag &= ~CSTOPB; /* 1.5 stop bits */
    }
    else if (0 == strcmp (stopbit, "2")) {
        sattr->termios_new.c_cflag |= CSTOPB;  /* 2 stop bits */
    }
    else {
        sattr->termios_new.c_cflag &= ~CSTOPB; /* 1 stop bit */
    }
}

static void SetParityCheck (SerialAttr* sattr, char parity)
{
    switch (parity) {
    case 'N':                  /* no parity check */
        sattr->termios_new.c_cflag &= ~PARENB;
        break;
    case 'E':                  /* even */
        sattr->termios_new.c_cflag |= PARENB;
        sattr->termios_new.c_cflag &= ~PARODD;
        break;
    case 'O':                  /* odd */
        sattr->termios_new.c_cflag |= PARENB;
        sattr->termios_new.c_cflag |= ~PARODD;
        break;
    default:                   /* no parity check */
        sattr->termios_new.c_cflag &= ~PARENB;
        break;
    }
}

int ComPortSetPortAttr (SerialAttr* sattr, int baudrate,
                          int databit, const char *stopbit, char parity)
{
	if(sattr->fd<0){
		return -1;
	}
    bzero (&sattr->termios_new, sizeof (sattr->termios_new));
    cfmakeraw (&sattr->termios_new);
    SetBaudrate (sattr, baudrate);
    sattr->termios_new.c_cflag |= CLOCAL | CREAD;      /* | CRTSCTS */
    SetDataBit (sattr, databit);
    SetParityCheck (sattr, parity);
    SetStopBit (sattr, stopbit);
    sattr->termios_new.c_oflag = 0;
    sattr->termios_new.c_lflag |= 0;
    sattr->termios_new.c_oflag &= ~OPOST;
    sattr->termios_new.c_cc[VTIME] = 1;        /* unit: 1/10 second. */
    sattr->termios_new.c_cc[VMIN] = 1; /* minimal characters for reading */
    tcflush (sattr->fd, TCIFLUSH);
    return (tcsetattr (sattr->fd, TCSANOW, &sattr->termios_new));
}

static int BAUDRATE (int baudrate)
{
    switch (baudrate) {
    case 1200:
        return (B1200);
    case 2400:
        return (B2400);
    case 4800:
        return (B4800);
    case 9600:
        return (B9600);
    case 19200:
        return (B19200);
    case 38400:
        return (B38400);
    case 57600:
        return (B57600);
    case 115200:
        return (B115200);
    default:
        return (B9600);
    }
}

static int _BAUDRATE (int baudrate)
{
/* reverse baudrate */
    switch (baudrate) {
    case B1200:
        return (1200);
    case B2400:
        return (2400);
    case B4800:
        return (4800);
    case B9600:
        return (9600);
    case B19200:
        return (19200);
    case B38400:
        return (38400);
    case B57600:
        return (57600);
    case B115200:
        return (115200);
    default:
        return (9600);
    }
}



