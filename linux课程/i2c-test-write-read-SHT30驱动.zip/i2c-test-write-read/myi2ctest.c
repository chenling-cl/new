
/*
Write by Long
2020-05-17
*/


#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <linux/i2c.h>
#include <linux/i2c-dev.h>
#include <termios.h>
#include <sys/signal.h>

#include "serial.h"

static SerialAttr uart_sattr={
	.fd=-1,
};


int SYSUART_OpenDev(unsigned char* uartdev, unsigned int port, unsigned int baudrate)
{
	unsigned int tmp;
	
	if(uartdev){
		tmp=strlen(uartdev);
		port=0;
		while(tmp){
			--tmp;
			if((uartdev[tmp]>'9')||(uartdev[tmp]<'0')){
				++tmp;
				port = atoi(&uartdev[tmp]);
				uartdev[tmp]=0;
				break;
			}
		}
	}else{
		uartdev = "/dev/ttyS";
	}

	return OpenComPort(&uart_sattr, uartdev, port, baudrate, 8, "1", 'N');
}

void SYSUART_CloseDev(void)
{
	if(uart_sattr.fd>=0){
		CloseComPort(&uart_sattr);
	}
}

int SYSUART_RecCMD(unsigned char* recbuf, unsigned int len)
{
	unsigned int reclen;
	unsigned int num;
	int ret;

	reclen=0;
	while(1){
		ret=ReadComPort(&uart_sattr, &recbuf[reclen], (len-reclen));
		if(ret>0){
			reclen += ret;
			for(num=0; num<reclen; ++num){
				if((recbuf[num]=='\r')||(recbuf[num]=='\n')){
					recbuf[num]=0;
					return num;
				}
			}
			if(reclen>=len){
				reclen=0;
			}
		}
	}
	return reclen;
}







int SYSI2C_DevWrite(int fd, unsigned int i2c_addr, unsigned char *buf, unsigned int num)
{
	int ret;
	struct i2c_rdwr_ioctl_data ctldata;
	
	struct i2c_msg msgs[] = {
		{
			.addr	= i2c_addr,
			.flags	= 0,
			.len	= num,
			.buf	= buf,
		},
	};
	ctldata.msgs=msgs;
	ctldata.nmsgs=1;
	ret = ioctl(fd, I2C_RDWR, &ctldata);
	if(ret<0) return ret;
	return ret;
}


int SYSI2C_DevRead(int fd, unsigned int i2c_addr, unsigned char *buf, unsigned int reg_len, unsigned int num)
{
	int ret;
	struct i2c_rdwr_ioctl_data ctldata;
	
	struct i2c_msg msgs[] = {
		{
			.addr	= i2c_addr,
			.flags	= 0,
			.len	= reg_len,
			.buf	= buf,
		},
		{
			.addr	= i2c_addr,
			.flags	= I2C_M_RD,
			.len	= num,
			.buf	= buf,
		},
	};
	ctldata.msgs=msgs;
	ctldata.nmsgs=2;
	ret = ioctl(fd, I2C_RDWR, &ctldata);
	if(ret<0) return ret;
	return ret;
}




unsigned int gethex_form_char(unsigned char* srcbuf, unsigned char* destbuf, unsigned int max_len)
{
	unsigned int num;

	unsigned int total;
	unsigned int valid;
	unsigned int tmpvalue;
	unsigned int count;
	
	total=0;
	count=0;
	num=0;
	while(srcbuf[num]){
		valid=0;
		if((srcbuf[num] <= '9') && (srcbuf[num] >= '0')){
			valid=1;
			tmpvalue=srcbuf[num]-'0';
		}
		else if((srcbuf[num] <= 'F') && (srcbuf[num] >= 'A')){
			valid=1;
			tmpvalue=srcbuf[num]-('A'-10);
		}
		else if((srcbuf[num] <= 'f') && (srcbuf[num] >= 'a')){
			valid=1;
			tmpvalue=srcbuf[num]-('a'-10);
		}
		if(valid){
			if(count){
				destbuf[total] <<= 4;
				destbuf[total] += tmpvalue;
				++total;
				count=0;
			}else{
				destbuf[total] = tmpvalue;
				++count;
			}
		}else{
			if(count){
				++total;
			}
			count=0;
		}
		if(total >= max_len) break;
		++num;
	}
	return total;
}

unsigned int getaddr_form_char(unsigned char *srcbuf, unsigned int* bytes)
{
	unsigned char tmpbuf[16];
	unsigned int len;
	unsigned int value;
	unsigned int num;
	
	if((srcbuf[0]=='0')&&((srcbuf[1]=='X')||(srcbuf[1]=='x')))
	{
		len=gethex_form_char(&srcbuf[2], tmpbuf, 16);
		if(bytes) *bytes=len;
		value=0;
		for(num=0; num<len; ++num){
			value <<= 8;
			value |= tmpbuf[num];
		}
	}else{
		value=atoi(srcbuf);
		*bytes=1;
	}
	return value;
}




int main(int argc, char * argv[])
{
	int i2c_fd;
	unsigned int num;
	unsigned int run_help;
	unsigned int i2c_clk;
	unsigned int i2c_addr;
	unsigned int i2c_reg;
	unsigned int i2c_write;
	unsigned int reg_len;
	unsigned int opt_total;
	unsigned char opt_buf[128];
	unsigned char devname[32];
	unsigned char uartbuf[512];
	char* token;
	unsigned char uartname[64];
	unsigned int baudrate;
	unsigned int workmark;

	int ret;
	unsigned int put[2]={0,0};	//��ʪ�Ȼ�������
    
    int n;
    
	uartname[0]=0;
	baudrate=115200;
	snprintf(devname, 32, "/dev/i2c-0");	/*default i2c dev*/
	i2c_clk=100000;	/*default i2c clk*/
	i2c_addr=0X50;	/*default i2c addr*/
	i2c_reg=0x00;	/*default i2c register*/
	i2c_write=0;	/*default is read*/
	opt_total=1;	/*default read or write bytes*/
	reg_len=1;
	run_help=0;
    do{                                                             //**********************************************************************************
    printf("\n");
	sleep(1);
	for(num=1; num<argc; ++num){
		if(strcmp("-h", argv[num])==0){
			run_help=1;
			break;
		}else if(strcmp("-d", argv[num])==0){
			/*set dev name*/
			if(argc>(num+1)){
				++num;
				snprintf(devname, 32, "%s", argv[num]);
			}else{
				run_help=1;
				break;
			}
		}else if(strcmp("-o", argv[num])==0){
			/*set uart dev name*/
			if(argc>(num+1)){
				++num;
				snprintf(uartname, 64, "%s", argv[num]);
			}else{
				run_help=1;
				break;
			}
		}else if(strcmp("-b", argv[num])==0){
			/*set uart dev baudrate*/
			if(argc>(num+1)){
				++num;
				baudrate = atoi(argv[num]);
			}else{
				run_help=1;
				break;
			}
		}else if(strcmp("-a", argv[num])==0){
			/*set i2c addr*/
			if(argc>(num+1)){
				++num;
				i2c_addr=getaddr_form_char(argv[num], NULL);
			}else{
				run_help=1;
				break;
			}
		}else if(strcmp("-c", argv[num])==0){
			/*set i2c clk*/
			if(argc>(num+1)){
				++num;
				i2c_clk=atoi(argv[num]);
			}else{
				run_help=1;
				break;
			}
		}else if(strcmp("-w", argv[num])==0){
			/*set i2c write to reg*/
			i2c_write =1;
			if(argc>(num+1)){
				++num;
				opt_total=gethex_form_char(argv[num], opt_buf, 128);
			}else{
				run_help=1;
				break;
			}
		}else if(strcmp("-r", argv[num])==0){
			/*set i2c read from reg*/
			i2c_write = 0;
			if(argc>(num+1)){
				++num;
				i2c_reg=getaddr_form_char(argv[num], &reg_len);
			}else{
				run_help=1;
				break;
			}
			if(argc>(num+1)){
				++num;
				opt_total=atoi(argv[num]);
			}else{
				run_help=1;
				break;
			}
		}else{
			break;
		}
	}
	if(run_help){
		printf("I2C test\n -h    print help\n \
			-o    set uart out port\n \
			-b    set uart baudrate\n \
			-d    set i2c device path\n \
			-a    set i2c slave addr\n \
			-w    set i2c write\n \
			-r    set i2c read\n \
			such as:\n \
			./i2c-test -d /dev/i2c-1 -a 0X51 -o /dev/ttyS3 -b 9600\n \
			./i2c-test -d /dev/i2c-1 -a 0X51 -r 0X02 8\n \
			./i2c-test -d /dev/i2c-1 -a 0X51 -r 0X0203 8\n \
			./i2c-test -d /dev/i2c-1 -a 0X51 -w 00FB3C4D98\n");
		return 0;
	}
	if(i2c_write){
		if(opt_total==0){
			printf("Please enter write data!\n");
			return -2;
		}
		printf("You want to write addr=%02X; data=", i2c_addr);
		for(num=0; num<opt_total; ++num){
			printf("%02X ", opt_buf[num]);
		}
		printf("\n");
	}else{
		if(opt_total==0){
			opt_total=1;
		}
		printf("You want to read addr=%02X; reg=%08X; total=%d\n", i2c_addr, i2c_reg, opt_total);
	}
	printf("Open %s !\n", devname);
	/*Every is ready, start operate*/
	i2c_fd = open(devname, O_RDWR);
	if ( i2c_fd < 0 ){
		printf("Error: Open %s failed!\n", devname);
		return -1;
	}
#if 0	/*not support!*/
	if(i2c_clk<=400) i2c_clk*=1000;
	printf("Set I2C clk=%d\n", i2c_clk);
#endif

	workmark=1;
	if(uartname[0]){
		ret=SYSUART_OpenDev(uartname, 0, baudrate);
		if(ret){
			uartname[0]=0;
		}
	}
	while(workmark){
		if(opt_total){
			if(i2c_write){
				ret=SYSI2C_DevWrite(i2c_fd, i2c_addr, opt_buf, opt_total);
				if(ret>=0){
					snprintf(uartbuf, 128, "Write 0X%02X OK\n", i2c_addr);
				}else{
					snprintf(uartbuf, 128, "Write 0X%02X Failed\n", i2c_addr);
				}
				if(uartname[0]){
					WriteComPort(&uart_sattr, uartbuf, strlen(uartbuf));
				}else printf(uartbuf);
			}else{
				memset(opt_buf, 0, sizeof(opt_buf));
		#if 1	/*MSB-->LSB,���ֽ���ǰ*/
				num=reg_len;
				while(num){
					--num;
					opt_buf[num]=i2c_reg & 0XFF;
					i2c_reg >>= 8;
				}
		#else	/*LSB-->MSB,���ֽ���ǰ*/
				for(num=0; num<reg_len; ++num){
					opt_buf[num]=i2c_reg & 0XFF;
					i2c_reg >>= 8;
				}
		#endif
 				ret=SYSI2C_DevRead(i2c_fd, i2c_addr, opt_buf, reg_len, opt_total);
				if(ret>=0){
					snprintf(uartbuf, 512, "Read %d: ", opt_total);
					ret=strlen(uartbuf);
					for(num=0; num<opt_total; ++num){
						snprintf(&uartbuf[ret], 512, "%02X ", opt_buf[num]);
						ret+=3;
						if(ret>500){
							break;
						}
					}
					uartbuf[ret]='\n';
					++ret;
					uartbuf[ret]=0;
				}else{
					snprintf(uartbuf, 128, "Read 0X%02X Failed \n", i2c_addr);
				}
				if(uartname[0]){
					WriteComPort(&uart_sattr, uartbuf, strlen(uartbuf));
				}else printf(uartbuf);
                //ʮ���������ʪ������
				put[0]=(unsigned int)opt_buf[0]*256+(unsigned int)opt_buf[1];
				put[1]=(unsigned int)opt_buf[3]*256+(unsigned int)opt_buf[4];
				printf("temperature = %.2f C\nhumidity    = %.2f RH\n",(put[0]/65535.0)*175-45,(put[1]/65535.0)*100);
			}
		}
		if(uartname[0]){
			SYSUART_RecCMD(uartbuf, 128);
			opt_total=0;
			token=strtok(uartbuf, " ");
			if(token){
				if(strcmp("-w", token)==0){
					/*set i2c write to reg*/
					i2c_write =1;
					token=strtok(NULL, " ");
					if(token){
						opt_total=gethex_form_char(token, opt_buf, 128);
					}
				}else if(strcmp("-r", token)==0){
					/*set i2c read from reg*/
					i2c_write = 0;
					token=strtok(NULL, " ");
					if(token){
						i2c_reg=getaddr_form_char(token, &reg_len);
						opt_total=1;
						token=strtok(NULL, " ");
						if(token){
							opt_total=atoi(token);
						}
					}
				}else if(strcmp("exit", token)==0){
					workmark=0;	/*����*/
					break;
				}
			}
		}else{
			workmark=0;	/*����*/
		}
	}
	close(i2c_fd);
	SYSUART_CloseDev();
     printf("\n");
}while(i2c_write==0&&put[0]!=0);                //*************************************************************************************************************************
	return  0;
} 




