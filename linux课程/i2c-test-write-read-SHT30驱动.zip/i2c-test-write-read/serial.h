


typedef struct SerialAttr{
	int    fd;             //File descriptor for the port
	unsigned int extend_uart;
	struct termios termios_old, termios_new;
	fd_set   fs_read, fs_write;
	struct timeval tv_timeout;
	struct sigaction sigaction_io;   /* definition of signal action */
}SerialAttr;


int OpenComPort (SerialAttr* sattr, char* device, int ComPort, int baudrate, int databit,
                   const char *stopbit, char parity);

void CloseComPort (SerialAttr* sattr);

int ReadComPort (SerialAttr* sattr, void *data, int datalength);


int WriteComPort (SerialAttr* sattr, unsigned char* data, int datalength);




